# Time Shift Clock (Floating Overlay)

A native Android app that displays a separate floating clock. The phone's real system time is never changed.

- Tap the floating clock: +5 minutes.
- Repeated taps: +10, +15, +20 minutes, etc.
- The shifted clock continues advancing in real time.
- ↺ button resets to real time.
- Drag the clock to move it.
- Runs as a visible foreground service.
- Requires Android's "Display over other apps / Appear on top" permission.

## Build without Android Studio
A GitHub Actions workflow is included. Upload this folder to a GitHub repository, then open **Actions → Build APK** and download the APK artifact.

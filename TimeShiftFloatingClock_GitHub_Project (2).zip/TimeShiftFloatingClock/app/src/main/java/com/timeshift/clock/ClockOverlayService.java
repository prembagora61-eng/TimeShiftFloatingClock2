package com.timeshift.clock;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.*;
import android.content.pm.ServiceInfo;
import android.provider.Settings;
import android.view.*;
import android.widget.*;
import android.graphics.drawable.GradientDrawable;
import java.text.SimpleDateFormat;
import java.util.*;

public class ClockOverlayService extends Service {
    private static final int NOTIF_ID = 101;
    private static final String CHANNEL = "timeshift_clock";
    private static ClockOverlayService instance;
    private WindowManager wm; private LinearLayout box; private TextView clock; private TextView reset; private Handler handler;
    private float downX, downY; private int startX, startY; private boolean moved;

    public static void requestUpdate() { if (instance != null) instance.updateClock(); }

    @Override public void onCreate() { super.onCreate(); instance = this; handler = new Handler(Looper.getMainLooper()); createChannel(); showOverlay(); }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) { NotificationChannel c = new NotificationChannel(CHANNEL, "Time Shift Clock", NotificationManager.IMPORTANCE_LOW); c.setDescription("Floating clock is running"); getSystemService(NotificationManager.class).createNotificationChannel(c); }
    }

    private void showOverlay() {
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return; }
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new Notification.Builder(this, CHANNEL).setSmallIcon(android.R.drawable.ic_menu_recent_history).setContentTitle("Time Shift Clock active").setContentText("Tap the floating clock to add 5 minutes").setContentIntent(pi).setOngoing(true).build();
        if (Build.VERSION.SDK_INT >= 29) startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE); else startForeground(NOTIF_ID, n);

        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        box = new LinearLayout(this); box.setOrientation(LinearLayout.HORIZONTAL); box.setGravity(Gravity.CENTER_VERTICAL); box.setPadding(8, 4, 5, 4); box.setBackgroundResource(com.timeshift.clock.R.drawable.rounded_bg);
        clock = new TextView(this); clock.setTextColor(Color.WHITE); clock.setTextSize(22); clock.setTypeface(null, 1); clock.setGravity(Gravity.CENTER); clock.setMinWidth(150);
        reset = new TextView(this); reset.setText("↺"); reset.setTextColor(Color.WHITE); reset.setTextSize(20); reset.setGravity(Gravity.CENTER); reset.setBackgroundResource(com.timeshift.clock.R.drawable.reset_bg); reset.setPadding(12, 5, 12, 5);
        reset.setOnClickListener(v -> { getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE).edit().putLong(MainActivity.OFFSET, 0).apply(); updateClock(); });
        box.addView(clock); box.addView(reset, new LinearLayout.LayoutParams(-2, -2));

        box.setOnTouchListener((v, e) -> {
            switch(e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN: downX=e.getRawX(); downY=e.getRawY(); startX=lastParams.x; startY=lastParams.y; moved=false; return true;
                case MotionEvent.ACTION_MOVE: int dx=(int)(e.getRawX()-downX), dy=(int)(e.getRawY()-downY); if(Math.abs(dx)>8||Math.abs(dy)>8)moved=true; lastParams.x=startX+dx; lastParams.y=startY+dy; try{wm.updateViewLayout(box,lastParams);}catch(Exception ignored){} return true;
                case MotionEvent.ACTION_UP: if(!moved){ addFiveMinutes(); } return true;
            } return true;
        });

        lastParams = new WindowManager.LayoutParams(-2, -2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT);
        lastParams.gravity=Gravity.TOP|Gravity.START; lastParams.x=20; lastParams.y=100;
        wm.addView(box,lastParams); updateClock();
        handler.post(ticker);
    }

    private WindowManager.LayoutParams lastParams;
    private final Runnable ticker = new Runnable(){ public void run(){ updateClock(); handler.postDelayed(this,500); }};

    private void addFiveMinutes(){ SharedPreferences p=getSharedPreferences(MainActivity.PREFS,MODE_PRIVATE); long m=p.getLong(MainActivity.OFFSET,0)+5; p.edit().putLong(MainActivity.OFFSET,m).apply(); updateClock(); }
    private void updateClock(){ if(clock==null)return; long off=getSharedPreferences(MainActivity.PREFS,MODE_PRIVATE).getLong(MainActivity.OFFSET,0); long now=System.currentTimeMillis()+off*60_000L; String t=new SimpleDateFormat("HH:mm",Locale.getDefault()).format(new Date(now)); clock.setText(t); }

    @Override public int onStartCommand(Intent i,int flags,int id){ return START_NOT_STICKY; }
    @Override public void onDestroy(){ instance=null; if(handler!=null)handler.removeCallbacksAndMessages(null); if(box!=null&&wm!=null)try{wm.removeView(box);}catch(Exception ignored){} super.onDestroy(); }
    @Override public android.os.IBinder onBind(Intent i){ return null; }
}

package com.timeshift.clock;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.graphics.Color;

public class MainActivity extends Activity {
    static final String PREFS = "clock_prefs";
    static final String OFFSET = "offset_minutes";
    private SharedPreferences prefs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL); root.setPadding(32, 48, 32, 32);
        root.setGravity(Gravity.CENTER_HORIZONTAL); root.setBackgroundColor(Color.BLACK);

        TextView title = new TextView(this); title.setText("Time Shift Clock"); title.setTextColor(Color.WHITE); title.setTextSize(28); title.setGravity(Gravity.CENTER);
        root.addView(title, new LinearLayout.LayoutParams(-1, -2));
        TextView info = new TextView(this); info.setText("Floating clock • Tap clock = +5 minutes"); info.setTextColor(Color.LTGRAY); info.setTextSize(16); info.setGravity(Gravity.CENTER); info.setPadding(0, 20, 0, 30);
        root.addView(info, new LinearLayout.LayoutParams(-1, -2));

        Button start = new Button(this); start.setText("START FLOATING CLOCK");
        start.setOnClickListener(v -> startClock()); root.addView(start, new LinearLayout.LayoutParams(-1, -2));
        Button reset = new Button(this); reset.setText("RESET TO REAL TIME");
        reset.setOnClickListener(v -> { prefs.edit().putLong(OFFSET, 0).apply(); ClockOverlayService.requestUpdate(); }); root.addView(reset, new LinearLayout.LayoutParams(-1, -2));
        Button stop = new Button(this); stop.setText("STOP FLOATING CLOCK");
        stop.setOnClickListener(v -> stopService(new Intent(this, ClockOverlayService.class))); root.addView(stop, new LinearLayout.LayoutParams(-1, -2));

        TextView note = new TextView(this); note.setText("The app does NOT change your phone's system time. It only shows a separate floating clock."); note.setTextColor(Color.GRAY); note.setTextSize(14); note.setPadding(0, 35, 0, 0);
        root.addView(note, new LinearLayout.LayoutParams(-1, -2));
        setContentView(root);
    }

    private void startClock() {
        if (!Settings.canDrawOverlays(this)) {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())); startActivity(i); return;
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 10); return;
        }
        Intent s = new Intent(this, ClockOverlayService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(s); else startService(s);
    }

    @Override protected void onResume() { super.onResume(); }
}
